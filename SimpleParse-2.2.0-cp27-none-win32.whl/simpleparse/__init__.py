'''Simple parsing using mxTextTools

See the /doc subdirectory for introductory and
general documentation.  See license.txt for licensing
information.  (This is a BSD-licensed package).
'''
__version__="2.2.0"
